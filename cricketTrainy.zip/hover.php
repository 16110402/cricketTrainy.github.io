<?php
  echo '<div class="card-group text-center" style="margin-left:50px;margin-right:50px;margin-top:50px;margin-bottom:50px;">
  <div class="card" id="zoom">
    <div class="card-body" style="hover:yellow;">
      <h5 class="card-title">Setup Curriculum</h5>
      <p class="card-text" style="color:grey;">Cricket is no less than a religion in India. From chawls to plush housing societies. From schools to offices. Cricket is an important element of Indian lives. From a father’s memories to a youngster’s role model, the names of cricketers are taken in every house here. Thus, it is unsurprising to know that many want to pursue cricket as their profession. After all, cricketers are one of the most successful sportspersons. But in a competitive environment like cricket where millions dream of donning the famous Blue jersey, where you train also matters.</p>
    </div>
  </div>
  <div class="card" id="zoom">
    <div class="card-body" style="border: 5px solid red">
      <h5 class="card-title">Training Study</h5>
      <p class="card-text" style="color:grey;">his four year Integrated Masters in Cricket Coaching and Management is the only course of its type in the UK.  Our innovative combination of cricket coaching, management and development will equip you with operational, strategic and project management expertise to enable you to take a dynamic approach to leading innovation and change within the sector. 
      The course is supported by the England and Wales Cricket Board (ECB), Worcestershire County Cricket Club and County Cricket Boards including Gloucestershire & Worcestershire.</p>
    </div>
  </div>
  <div class="card" id="zoom">
    <div class="card-body">
      <h5 class="card-title">Provide Feedback</h5>
      <p class="card-text" style="color:grey;">The Cricket Coaching mat I use is the best aid to coaching batting to junior cricketers I have ever had and is suitable for all junior age groups. It is versatile in that you can set up multi tee positions on the mat at the same time. The velcro footpads really help boys and girls to get their feet into the correct position for shots. The tee positions make sure the same position is achieved each time, imperative for repetition, when the boys/girls are working in their own groups. I use the mat for throw downs, too, and also for target bowling. </p>
    </div>
  </div>
</div>';
?>