<?php
     echo '<div  class="container-fluid">
     <img src="gautam.jpg" class="img-responsive" alt="Gautam" width="100%" height="750">
     <div class="top-left">
     <a class="logo" href="#"><img style="height:50px;width:50px;" src="logo.JPG" alt="logo">cricketTrainy</a>
     </div>
     <div class="top-right">
     <nav class="navbar navbar-expand-lg" id="nv">
    <button class="navbar-toggler navbar-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse mx-5 navbar-light" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Trainings</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Terms & Conditions </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Career </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Feedback </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact us </a>
        </li>
      </ul>
  </div>
</nav>
     </div>
     <div class="centered">
     <ul class="cont">
    <li class="con">WELCOME TO YOUR ACADEMY</li>
    <li class="con1">MAKE YOURSELF FOR YOUR COUNTRY</li>
    <li><button type="button" id="bt1" class="btn btn-light">Get Started</button></li>
   </ul>
   </div>';
?>
 <!-- echo '<img src="gautam.jpg" class="img-responsive" alt="Gautam"  width="100%" height="700">'; -->